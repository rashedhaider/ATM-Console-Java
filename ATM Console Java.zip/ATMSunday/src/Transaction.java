import java.util.Date;

public class Transaction {
	
	/**
	 * The amount of this transaction.
	 */
	private double amount;
	
	/**
	 * The time and date of this transaction.
	 */
	private Date timestamp;
	
	/**
	 * A user note for this transaction.
	 */
	private String memo;
	
	/**
	 * Create a new transaction.
	 * @param amount		the GBP amount transacted
	 * @param in_Acct	the account the transaction belongs to
	 */
	public Transaction(double amount, Account in_Acct) {
		
		this.amount = amount;
		this.timestamp = new Date();
		this.memo = "";
		
	}
	
	/**
	 * Create a new transaction with a note.
	 * @param amount	the amount to be transacted
	 * @param memo		the note the user to reference the transaction
	 * @param in_Acct	the account the transaction belongs to
	 */
	public Transaction(double amount, String memo, Account in_Acct) {
		
		// call the single-arg constructor first
		this(amount, in_Acct);
		
		this.memo = memo;
		
	}
	
	/**
	 * Display the transaction amount.
	 */
	public double fetchAmount() {
		return this.amount;
	}
	
	/**
	 * Pull a string to summarise  the transaction
	 */
	public String fetchSummaryLine() {
		
		if (this.amount >= 0) {
			return String.format("%s, GBP.%.02f : %s", 
					this.timestamp.toString(), this.amount, this.memo);
		} else {
			return String.format("%s, GBP.(%.02f) : %s", 
					this.timestamp.toString(), -this.amount, this.memo);
		}
	}

}
