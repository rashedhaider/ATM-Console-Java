import java.util.Scanner;

public class ATM {
	

	public static void main(String[] args) {
		
		// Intializing scanner class to obtain user input 
		
		Scanner sc = new Scanner(System.in);
		
		// intializing the Bank class by giving a hypothetical name of the bank
		Bank eBank = new Bank("E-corp Bank");
		
		// add a user, which creates a Current and a Savings account.
		User aUser = eBank.addUser("Rashed","Haider", "4252");
		Account newAccount = new Account("Current Account", aUser, eBank);
		aUser.addAccount(newAccount);
		eBank.addAccount(newAccount);
		
		User tempUser;
		
		
		// stay in login prompt until successful login
		tempUser = ATM.loginPrompt(eBank, sc);
		// continue looping forever
		 
		if (tempUser == null) {
			System.out.print("Null Error");	
		}
		else {		
			// stay in main menu until user quits
			ATM.printMainMenu(tempUser, sc);
		}
			
		
	}
	/**
	 * Display ATM's login menu prompting user to enter card number and PIN
	 */
	public static User loginPrompt(Bank eBank, Scanner sc) {
		
		String userID;
		String pin;
		User validUserO;
		User validUser = null;
		
		int counter = 1;
		
		while (counter <= 3) {
			
			System.out.printf("\n\nWelcome to %s\n\n", eBank.fetchName());		
			System.out.print("Plese Enter Your 6 Digit Card No: ");
			userID = sc.nextLine();
			System.out.print("Now Enter Your 4 Digit  PIN: ");
			pin = sc.nextLine();
			
			validUserO = eBank.user_login(userID, pin);
			if (validUserO == null) {
				System.out.println("Incorrect Card no/PIN combination. " + 
						" Plesae Retry .");
				counter++;
				
			}
			else {
				validUser = validUserO;
				counter = 4;
			}
			
		}  	// continue looping until we have a  
									// successful login**NEED TO CHANGE IT TO 3 LOG IN ATTEMPT****
		
		if (counter == 3) {
			System.out.print("Error attempts");
			
		}
		
		return validUser;
		
		
		
	}
	
	/**
	 * Print the ATM's menu for the active user who log in successfully
.
	 */
	public static void printMainMenu(User eUser, Scanner sc) {
		// intiliaze
	
		eUser.printAccountsSummary();
		// ATM menu to loged in user 
		int choiceInt = 0;
		int checker = 1;
		while(checker <= 1) {
			// Welcome message from the bank
			System.out.println("Welcome to the ATM: Select Between option 1 - 5");
			
			// case 1 to show the transaction history 
			System.out.println("  1) Display transaction history");
			System.out.println("  2) Withdraw Money");
			System.out.println("  3) Deposit Money");
			System.out.println("  4) Transfer Funds");
			System.out.println("  5) Exit");
			System.out.println();
			System.out.print("Enter choice: ");
			String choice = sc.next();
			
			
			if (choice.matches("\\d+")) {
				checker++;
				
				choiceInt = Integer.parseInt(choice);
				
				if (choiceInt < 1 || choiceInt > 5) {
					System.out.println("invalid option; plese select a number between 1 - 5 ");
					ATM.printMainMenu(eUser, sc);
				}
				else {
					switch (choiceInt) {
					
					case 1:
						ATM.showTransHistory(eUser, sc);
						printMainMenu(eUser, sc);
						break;
					case 2:
						ATM.withdrawMoney(eUser, sc);
						printMainMenu(eUser, sc);
						break;
					case 3:
						ATM.depositMoney(eUser, sc);
						printMainMenu(eUser, sc);
						break;
					case 4:
						ATM.transferMoney(eUser, sc);
						printMainMenu(eUser, sc);
						break;
					case 5:
						main(null);
					
						break;
					}
					// ** Try and catch 
					
				}
			}
			else {
				System.out.println("Invalid format select a number");
			}
			
			
			
			
		} 
		
		
	}
	
	/**
	 * Method call for transferring funds from one account to another.
	 */
	public static void transferMoney(User eUser, Scanner sc) {
		
		int fromAcctIndex;
		int toAcctIndex;
		double amount;
		double acctBal;
		
		// Get the account no  to transfer from
		do {
			System.out.printf("Enter the number (1 to %d) of the account to " + 
					"transfer from: ", eUser.num_accounts());
			fromAcctIndex = sc.nextInt()-1;
			if (fromAcctIndex < 0 || fromAcctIndex >= eUser.num_accounts()) {
				System.out.println("Invalid account. Please try again.");
			}
		} while (fromAcctIndex < 0 || fromAcctIndex >= eUser.num_accounts());
		acctBal = eUser.fetchAcctBalance(fromAcctIndex);
		
		// Get the account no transfer to
		do {
			System.out.printf("Enter the number (1 to %d) of the account to " + 
					"transfer to: ", eUser.num_accounts());
			toAcctIndex = sc.nextInt()-1;
			if (toAcctIndex < 0 || toAcctIndex >= eUser.num_accounts()) {
				System.out.println("Invalid account. Please try again.");
			}
		} while (toAcctIndex < 0 || toAcctIndex >= eUser.num_accounts());
		
		// fetch amount to transfer
		do {
			System.out.printf("Enter the amount to transfer :");
			amount = sc.nextDouble();
			if (amount < 0) {
				System.out.println("Amount must be greater than zero.");
			} else if (amount > acctBal) {
				System.out.printf("Amount must not be greater than balance. ");
			}
		} while (amount < 0 || amount > acctBal);
		
		// finally, do the transfer 
		eUser.addAcctTransaction(fromAcctIndex, -1*amount, String.format(
				"Transfer to account %s", eUser.fetchAcctUUID(toAcctIndex)));
		eUser.addAcctTransaction(toAcctIndex, amount, String.format("Transfer from account %s", eUser.fetchAcctUUID(fromAcctIndex)));
		
	}
	
	/**
	 * Process a fund withdraw from an account to another.
	 */
	public static void withdrawMoney(User eUser, Scanner sc) {
		
		int acctIndex;
		double amount;
		double acctBal;
		String ministat;
		
		// fetch account to withdraw from
		do {
			System.out.printf("Enter the number (1 to %d) of the account to " + 
					"withdraw from: ", eUser.num_accounts());
			acctIndex = sc.nextInt()-1;
			if (acctIndex < 0 || acctIndex >= eUser.num_accounts()) {
				System.out.println("Invalid account. Please try again.");
			}
		} while (acctIndex < 0 || acctIndex >= eUser.num_accounts());
		acctBal = eUser.fetchAcctBalance(acctIndex);
		
		// fetch amount to transfer
		do {
			System.out.printf("Enter the amount to withdraw : £. ");
			amount = sc.nextDouble();
			if (amount < 0) {
				System.out.println("Amount must be greater than zero.");
			} else if (amount > acctBal) {
				System.out.printf("Amount must not be greater than balance.");
			}
		} while (amount < 0 || amount > acctBal);
		
		// gobble up rest of previous input
		sc.nextLine();
		
		// Asking user to post a usefull note for this transaction.
		System.out.print("Enter note for this transaction: ");
		ministat = sc.nextLine();
		
		// do the withdrawal
		eUser.addAcctTransaction(acctIndex, -1*amount, ministat);
		
	}
	
	/**
	 * Process a fund deposit to an account.
	 */
	public static void depositMoney(User eUser, Scanner sc) {
		
		int acctIndex;
		double amount;
		String ministat;
		
		// Get account to withdraw from
		do {
			System.out.printf("Enter the number (1 to %d) of the account to " + 
					"deposit to: ", eUser.num_accounts());
			acctIndex = sc.nextInt()-1;
			if (acctIndex < 0 || acctIndex >= eUser.num_accounts()) {
				System.out.println("Invalid account. Please try again.");
			}
		} while (acctIndex < 0 || acctIndex >= eUser.num_accounts());
		
		//  amount to transfer
		do {
			System.out.printf("Enter the amount to deposit: £.");
			amount = sc.nextDouble();
			if (amount < 0) {
				System.out.println("Amount must be greater than zero.");
			} 
		} while (amount < 0);
		
		// clear the rest of previous input
		sc.nextLine();
		
		// fetch a memo
		System.out.print("Enter Account note: ");
		ministat = sc.nextLine();
		
		// do the deposit
		eUser.addAcctTransaction(acctIndex, amount, ministat);
		
	}
	
	/**
	 * Show the transaction history for an account.
	 */
	public static void showTransHistory(User eUser, Scanner sc) {
		
		int acctIndex;
		
		// fetch account whose transactions to print
		do {
			System.out.printf("Enter the number (1 to %d) of the account\nwhich " + 
					"transactions you want to see: ", eUser.num_accounts());
			acctIndex = sc.nextInt()-1;
			if (acctIndex < 0 || acctIndex >= eUser.num_accounts()) {
				System.out.println("Invalid account. Please try again.");
			}
		} while (acctIndex < 0 || acctIndex >= eUser.num_accounts());
		
		// print the transaction history
		eUser.printAcctTransHistory(acctIndex);
		
	}

}